gcc main.c func.c -o app
app
pause