#include <stdio.h>
#include "func.h"

int main(void) {
    int item;
    
    do {
        printf("\nМЕНЮ\n");
        printf("0. Выход\n");
        printf("1. Выгрузка из TXT в BIN\n");
        printf("2. Вывод данных из BIN\n");
        printf("3. Добавление записи\n");
        printf("4. Редактирование записи\n");
        printf("5. Удаление записи\n");
        printf("6. Сортировка вставкой по клиенту\n");
        printf("7. Сортировка выбором по названию\n");
        printf("8. Сортировка пузырьком по клиенту\n");
        printf("Выберите пункт: ");

        scanf("%d", &item);

        switch (item) {
            case 0:
                printf("Выход\n");
                break;

            case 1:
                txt_to_bin();
                break;

            case 2:
                print_bin();
                break;

            case 3:
                add();
                break;

            case 4:
                edit();
                break;

            case 5:
                delete();
                break;

            case 6:
                sort_insert_bin();
                break;

            case 7:
                sort_select_bin();
                break;

            case 8:
                sort_bubble_bin();
                break;

            default:
                printf("Неверный пункт меню\n");
        }

    } while (item != 0);

    return 0;
}