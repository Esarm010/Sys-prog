#include <stdio.h>
#include <string.h>
#include "func.h"

/* Выгрузка данных из TXT в BIN */
void txt_to_bin(void) {
    FILE *txt;
    FILE *bin;
    struct Repair x;

    txt = fopen(TXT_FILE, "r");
    if (txt == NULL) {
        printf("Ошибка открытия TXT файла\n");
        return;
    }

    bin = fopen(BIN_FILE, "wb");
    if (bin == NULL) {
        printf("Ошибка открытия BIN файла\n");
        fclose(txt);
        return;
    }

    while (fscanf(txt, "%d.%d.%d %49s %49s %49s %49s",
                  &x.date.day,
                  &x.date.month,
                  &x.date.year,
                  x.client,
                  x.name,
                  x.maker,
                  x.category) == 7) {
        fwrite(&x, sizeof(struct Repair), 1, bin);
    }

    fclose(txt);
    fclose(bin);

    printf("Данные выгружены из TXT в BIN\n");
}

/* Вывод данных напрямую из BIN */
void print_bin(void) {
    FILE *bin;
    struct Repair x;
    int i = 1;

    bin = fopen(BIN_FILE, "rb");
    if (bin == NULL) {
        printf("Ошибка открытия BIN файла\n");
        return;
    }

    printf("\n№   Дата        Клиент        Название       Производитель  Категория\n");

    while (fread(&x, sizeof(struct Repair), 1, bin) == 1) {
        printf("%-3d %02d.%02d.%04d  %-12s  %-12s  %-14s  %s\n",
               i,
               x.date.day,
               x.date.month,
               x.date.year,
               x.client,
               x.name,
               x.maker,
               x.category);
        i++;
    }

    fclose(bin);
}

/* Добавление записи в конец BIN */
void add(void) {
    FILE *bin;
    struct Repair x;

    bin = fopen(BIN_FILE, "ab");
    if (bin == NULL) {
        printf("Ошибка открытия BIN файла\n");
        return;
    }

    printf("Введите дату дд мм гггг: ");
    scanf("%d %d %d", &x.date.day, &x.date.month, &x.date.year);

    printf("Введите клиента: ");
    scanf("%49s", x.client);

    printf("Введите название: ");
    scanf("%49s", x.name);

    printf("Введите производителя: ");
    scanf("%49s", x.maker);

    printf("Введите категорию: ");
    scanf("%49s", x.category);

    fwrite(&x, sizeof(struct Repair), 1, bin);

    fclose(bin);

    printf("Запись добавлена\n");
}

/* Редактирование записи*/
void edit(void) {
    struct Repair a[N];
    int n;
    int k;

    n = load(a);

    if (n == 0) {
        printf("Файл пуст или не найден\n");
        return;
    }

    print_bin();

    printf("\nВведите номер записи для редактирования: ");
    scanf("%d", &k);

    printf("Введите новую дату дд мм гггг: ");
    scanf("%d %d %d",
          &a[k - 1].date.day,
          &a[k - 1].date.month,
          &a[k - 1].date.year);

    printf("Введите нового клиента: ");
    scanf("%49s", a[k - 1].client);

    printf("Введите новое название: ");
    scanf("%49s", a[k - 1].name);

    printf("Введите нового производителя: ");
    scanf("%49s", a[k - 1].maker);

    printf("Введите новую категорию: ");
    scanf("%49s", a[k - 1].category);

    save(a, n);

    printf("Запись изменена\n");
}

/* Удаление записи через массив del[] */
void delete(void) {
    struct Repair a[N];
    int del[N] = {0};
    int n;
    int i;
    int k;
    FILE *bin;

    n = load(a);

    print_bin();

    printf("\nВведите номер записи для удаления: ");
    scanf("%d", &k);

    del[k - 1] = 1;

    bin = fopen(BIN_FILE, "wb");


    for (i = 0; i < n; i++) {
        if (del[i] == 0) {
            fwrite(&a[i], sizeof(struct Repair), 1, bin);
        }
    }

    fclose(bin);

    printf("Запись удалена\n");
}

/* Загрузка BIN в массив */
int load(struct Repair a[]) {
    FILE *bin;
    int n;

    bin = fopen(BIN_FILE, "rb");
    if (bin == NULL) {
        return 0;
    }

    n = fread(a, sizeof(struct Repair), N, bin);

    fclose(bin);

    return n;
}

/* Сохранение массива обратно в BIN */
void save(struct Repair a[], int n) {
    FILE *bin;

    bin = fopen(BIN_FILE, "wb");
    if (bin == NULL) {
        printf("Ошибка открытия BIN файла\n");
        return;
    }

    fwrite(a, sizeof(struct Repair), n, bin);

    fclose(bin);
}

/* Сортировка вставкой по клиенту */
void sort_insert_bin(void) {
    struct Repair a[N];
    struct Repair key;
    int n;
    int i;
    int j;

    n = load(a);

    for (i = 1; i < n; i++) {
        key = a[i];
        j = i - 1;

        while (j >= 0 && strcmp(a[j].client, key.client) > 0) {
            a[j + 1] = a[j];
            j--;
        }

        a[j + 1] = key;
    }

    save(a, n);

    printf("Сортировка вставкой выполнена\n");
}

/* Сортировка выбором по названию */
void sort_select_bin(void) {
    struct Repair a[N];
    struct Repair temp;
    int n;
    int i;
    int j;
    int min;

    n = load(a);

    for (i = 0; i < n - 1; i++) {
        min = i;

        for (j = i + 1; j < n; j++) {
            if (strcmp(a[j].name, a[min].name) < 0) {
                min = j;
            }
        }

        temp = a[i];
        a[i] = a[min];
        a[min] = temp;
    }

    save(a, n);

    printf("Сортировка выбором выполнена\n");
}

/* Сортировка пузырьком по клиенту */
void sort_bubble_bin(void) {
    struct Repair a[N];
    struct Repair temp;
    int n;
    int i;
    int j;

    n = load(a);

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (strcmp(a[j].client, a[j + 1].client) > 0) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    save(a, n);

    printf("Сортировка пузырьком выполнена\n");
}