#ifndef FUNC_H
#define FUNC_H

#include <stdio.h>

#define N 100
#define TXT_FILE "in.txt"
#define BIN_FILE "in.dat"

struct Date {
    int day;
    int month;
    int year;
};

struct Repair {
    struct Date date;
    char client[50];
    char name[50];
    char maker[50];
    char category[50];
};

void txt_to_bin(void);
void print_bin(void);
void add(void);
void edit(void);
void delete(void);
int load(struct Repair a[]);
void save(struct Repair a[], int n);
void sort_insert_bin(void);
void sort_select_bin(void);
void sort_bubble_bin(void);

#endif